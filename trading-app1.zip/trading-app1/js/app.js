// DOM Elements
const navbarToggle = document.getElementById('navbarToggle');
const navbarLinks = document.getElementById('navbarLinks');
const navbarProfile = document.getElementById('navbarProfile');
const profileMenu = document.getElementById('profileMenu');
const profileImageNav = document.getElementById('profileImageNav');
const toast = document.getElementById('toast');

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    // Load user data if available
    loadUserData();
    
    // Setup event listeners
    setupEventListeners();
    
    // Check for dark mode preference
    checkDarkMode();
});

// Setup event listeners
function setupEventListeners() {
    // Navbar toggle for mobile
    if (navbarToggle) {
        navbarToggle.addEventListener('click', toggleNavbar);
    }
    
    // Profile image click for menu
    if (profileImageNav) {
        profileImageNav.addEventListener('click', toggleProfileMenu);
    }
    
    // Close profile menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.navbar-profile') && !event.target.closest('.profile-menu')) {
            if (profileMenu && profileMenu.classList.contains('show')) {
                profileMenu.classList.remove('show');
            }
        }
    });
}

// Toggle navbar for mobile
function toggleNavbar() {
    navbarLinks.classList.toggle('show');
}

// Toggle profile menu
function toggleProfileMenu() {
    profileMenu.classList.toggle('show');
}

// Load user data from localStorage
function loadUserData() {
    const userData = JSON.parse(localStorage.getItem('userData'));
    
    if (userData) {
        // Update profile image in navbar
        if (profileImageNav) {
            if (userData.profileImage) {
                profileImageNav.src = userData.profileImage;
            } else {
                // Use avatar if no image
                profileImageNav.src = getAvatar(userData.name);
            }
        }
        
        // Update user greeting
        const userGreeting = document.getElementById('userGreeting');
        if (userGreeting) {
            userGreeting.textContent = userData.name;
        }
        
        // Update profile page if we're on it
        if (document.getElementById('profileName')) {
            document.getElementById('profileName').value = userData.name;
            document.getElementById('profileAmount').value = userData.initialAmount;
            document.getElementById('profilePercentage').value = userData.dailyPercentage;
            if (userData.profileImage) {
                document.getElementById('profileImageDisplay').src = userData.profileImage;
            } else {
                document.getElementById('profileImageDisplay').src = getAvatar(userData.name);
            }
        }
    }
}

// Generate avatar from name
function getAvatar(name) {
    const colors = ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6'];
    const firstLetter = name ? name.charAt(0).toUpperCase() : 'U';
    const colorIndex = name ? name.charCodeAt(0) % colors.length : 0;
    const color = colors[colorIndex];
    
    return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><rect width="100" height="100" fill="${color}" rx="50"/><text x="50" y="60" font-size="50" text-anchor="middle" fill="#ffffff">${firstLetter}</text></svg>`;
}

// Show toast notification
function showToast(message, type = 'success') {
    if (!toast) return;
    
    toast.textContent = message;
    toast.className = 'toast';
    toast.classList.add('show');
    
    if (type === 'success') {
        toast.style.backgroundColor = '#2ecc71';
    } else if (type === 'error') {
        toast.style.backgroundColor = '#e74c3c';
    } else if (type === 'warning') {
        toast.style.backgroundColor = '#f39c12';
    } else if (type === 'info') {
        toast.style.backgroundColor = '#3498db';
    }
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Check and apply dark mode
function checkDarkMode() {
    const darkModeEnabled = localStorage.getItem('darkMode') === 'enabled';
    const darkModeStyle = document.getElementById('dark-mode-style');
    
    if (darkModeEnabled && darkModeStyle) {
        darkModeStyle.disabled = false;
    }
}

// Initialize image modal
function initImageModal() {
    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('modalImage');
    const closeModal = document.querySelector('.close-modal');
    
    if (!modal) return;
    
    // Get all images that should open the modal
    const images = document.querySelectorAll('[data-modal-image]');
    
    images.forEach(img => {
        img.addEventListener('click', function() {
            modal.classList.add('show');
            modalImg.src = this.src;
        });
    });
    
    closeModal.addEventListener('click', function() {
        modal.classList.remove('show');
    });
    
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.classList.remove('show');
        }
    });
}

// Call this when the page loads
initImageModal();