// DOM Elements
const contactForm = document.getElementById('contactForm');
const contactName = document.getElementById('contactName');
const contactEmail = document.getElementById('contactEmail');
const contactSubject = document.getElementById('contactSubject');
const contactMessage = document.getElementById('contactMessage');

// Initialize contact page
document.addEventListener('DOMContentLoaded', function() {
    // Load user data to pre-fill name and email if available
    const userData = JSON.parse(localStorage.getItem('userData'));
    
    if (userData) {
        if (contactName) contactName.value = userData.name;
        if (contactEmail && userData.email) contactEmail.value = userData.email;
    }
    
    // Setup form submission
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactSubmit);
    }
});

// Handle contact form submission
function handleContactSubmit(e) {
    e.preventDefault();
    
    const name = contactName.value.trim();
    const email = contactEmail.value.trim();
    const subject = contactSubject.value.trim();
    const message = contactMessage.value.trim();
    
    // Simple validation
    if (!name) {
        showToast('Please enter your name', 'error');
        return;
    }
    
    if (!email || !isValidEmail(email)) {
        showToast('Please enter a valid email address', 'error');
        return;
    }
    
    if (!subject) {
        showToast('Please enter a subject', 'error');
        return;
    }
    
    if (!message) {
        showToast('Please enter your message', 'error');
        return;
    }
    
    // In a real app, you would send this to your server
    // For this demo, we'll just show a success message
    showToast('Message sent successfully!', 'success');
    
    // Reset form
    contactForm.reset();
    
    // Save email to user data if not already set
    const userData = JSON.parse(localStorage.getItem('userData'));
    if (userData && !userData.email) {
        userData.email = email;
        localStorage.setItem('userData', JSON.stringify(userData));
    }
}

// Simple email validation
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}