// DOM Elements
const profileForm = document.getElementById('profileForm');
const profileName = document.getElementById('profileName');
const profileAmount = document.getElementById('profileAmount');
const profilePercentage = document.getElementById('profilePercentage');
const profileImageDisplay = document.getElementById('profileImageDisplay');
const profileImageInput = document.getElementById('profileImageInput');
const imageOverlay = document.getElementById('imageOverlay');
const removeImageBtn = document.getElementById('removeImageBtn');
const cancelProfileBtn = document.getElementById('cancelProfileBtn');
const daysCompleted = document.getElementById('daysCompleted');
const successRate = document.getElementById('successRate');
const totalSavings = document.getElementById('totalSavings');
const totalLosses = document.getElementById('totalLosses');

// Initialize profile page
document.addEventListener('DOMContentLoaded', function() {
    loadProfileData();
    setupProfileEventListeners();
});

// Load profile data
function loadProfileData() {
    const userData = JSON.parse(localStorage.getItem('userData'));
    
    if (userData) {
        // Fill form fields
        if (profileName) profileName.value = userData.name;
        if (profileAmount) profileAmount.value = userData.initialAmount;
        if (profilePercentage) profilePercentage.value = userData.dailyPercentage;
        
        // Set profile image
        if (profileImageDisplay) {
            if (userData.profileImage) {
                profileImageDisplay.src = userData.profileImage;
            } else {
                profileImageDisplay.src = getAvatar(userData.name);
            }
        }
        
        // Calculate and display stats
        if (userData.tradingPlan) {
            let completed = 0;
            let achieved = 0;
            let totalS = 0;
            let totalL = 0;
            
            userData.tradingPlan.forEach(day => {
                if (day.day <= new Date().getDate() || day.lostMoney > 0 || !day.achieved) {
                    completed++;
                }
                if (day.achieved) achieved++;
                totalS += day.savingBalance;
                totalL += day.lostMoney;
            });
            
            if (daysCompleted) daysCompleted.textContent = `${completed}/30`;
            if (successRate) successRate.textContent = `${Math.round((achieved / completed) * 100) || 0}%`;
            if (totalSavings) totalSavings.textContent = `$${totalS.toFixed(2)}`;
            if (totalLosses) totalLosses.textContent = `$${totalL.toFixed(2)}`;
        }
    }
}

// Setup profile event listeners
function setupProfileEventListeners() {
    // Profile image upload
    if (imageOverlay) {
        imageOverlay.addEventListener('click', function() {
            profileImageInput.click();
        });
    }
    
    if (profileImageInput) {
        profileImageInput.addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(event) {
                    if (profileImageDisplay) {
                        profileImageDisplay.src = event.target.result;
                        
                        // Save to localStorage
                        const userData = JSON.parse(localStorage.getItem('userData'));
                        if (userData) {
                            userData.profileImage = event.target.result;
                            localStorage.setItem('userData', JSON.stringify(userData));
                            
                            // Update navbar image
                            const profileImageNav = document.getElementById('profileImageNav');
                            if (profileImageNav) {
                                profileImageNav.src = event.target.result;
                            }
                        }
                    }
                };
                
                reader.readAsDataURL(e.target.files[0]);
            }
        });
    }
    
    // Remove profile image
    if (removeImageBtn) {
        removeImageBtn.addEventListener('click', function() {
            const userData = JSON.parse(localStorage.getItem('userData'));
            if (userData) {
                userData.profileImage = '';
                localStorage.setItem('userData', JSON.stringify(userData));
                
                if (profileImageDisplay) {
                    profileImageDisplay.src = getAvatar(userData.name);
                }
                
                // Update navbar image
                const profileImageNav = document.getElementById('profileImageNav');
                if (profileImageNav) {
                    profileImageNav.src = getAvatar(userData.name);
                }
                
                showToast('Profile image removed', 'success');
            }
        });
    }
    
    // Cancel button
    if (cancelProfileBtn) {
        cancelProfileBtn.addEventListener('click', function() {
            window.location.href = 'home.html';
        });
    }
    
    // Form submission
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = profileName.value.trim();
            const amount = parseFloat(profileAmount.value);
            const percentage = parseFloat(profilePercentage.value);
            
            if (!name) {
                showToast('Please enter your name', 'error');
                return;
            }
            
            if (isNaN(amount) || amount <= 0) {
                showToast('Please enter a valid amount', 'error');
                return;
            }
            
            if (isNaN(percentage) || percentage <= 0 || percentage > 100) {
                showToast('Please enter a valid percentage between 1 and 100', 'error');
                return;
            }
            
            const userData = JSON.parse(localStorage.getItem('userData'));
            
            if (userData) {
                // Check if amount or percentage changed
                const amountChanged = userData.initialAmount !== amount;
                const percentageChanged = userData.dailyPercentage !== percentage;
                
                userData.name = name;
                userData.initialAmount = amount;
                userData.dailyPercentage = percentage;
                
                // If amount or percentage changed, regenerate trading plan
                if (amountChanged || percentageChanged) {
                    userData.tradingPlan = generateTradingPlan(amount, percentage);
                }
                
                localStorage.setItem('userData', JSON.stringify(userData));
                
                // Update navbar name if we're not changing it here
                const userGreeting = document.getElementById('userGreeting');
                if (userGreeting) {
                    userGreeting.textContent = name;
                }
                
                // Update navbar image
                const profileImageNav = document.getElementById('profileImageNav');
                if (profileImageNav && !userData.profileImage) {
                    profileImageNav.src = getAvatar(name);
                }
                
                showToast('Profile updated successfully!', 'success');
                setTimeout(() => {
                    window.location.href = 'home.html';
                }, 1500);
            }
        });
    }
}

// Generate avatar from name (duplicate from app.js, but needed here)
function getAvatar(name) {
    const colors = ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6'];
    const firstLetter = name ? name.charAt(0).toUpperCase() : 'U';
    const colorIndex = name ? name.charCodeAt(0) % colors.length : 0;
    const color = colors[colorIndex];
    
    return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><rect width="100" height="100" fill="${color}" rx="50"/><text x="50" y="60" font-size="50" text-anchor="middle" fill="#ffffff">${firstLetter}</text></svg>`;
}

// Generate trading plan (duplicate from trading.js, but needed here)
function generateTradingPlan(initialAmount, dailyPercentage) {
    const plan = [];
    let currentBalance = initialAmount;
    const percentage = dailyPercentage / 100;
    
    for (let day = 1; day <= 30; day++) {
        const profitToBeMade = currentBalance * percentage;
        const expectedBalance = currentBalance + profitToBeMade;
        const savingBalance = profitToBeMade * 0.5;
        
        plan.push({
            day,
            balance: currentBalance,
            profitToBeMade,
            expectedBalance,
            lostMoney: 0,
            savingBalance,
            achieved: true
        });
        
        currentBalance = currentBalance + (profitToBeMade - (profitToBeMade * 0.5));
    }
    
    return plan;
}