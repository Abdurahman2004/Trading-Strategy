// js/auth.js - Complete Authentication Script
document.addEventListener('DOMContentLoaded', function() {
    console.log('[Auth] Initializing authentication script');
    
    try {
        initializeSetupProcess();
        console.log('[Auth] Initialization complete');
    } catch (error) {
        console.error('[Auth] Initialization failed:', error);
        showErrorToast('Failed to initialize setup. Please refresh the page.');
    }
});

function initializeSetupProcess() {
    // Step 1: Name Entry
    const userNameInput = document.getElementById('user-name');
    const nextNameBtn = document.getElementById('next-name');
    
    // Step 2: Amount Selection
    const amountOptions = document.querySelectorAll('.amount-option');
    const initialAmountInput = document.getElementById('initial-amount');
    const nextAmountBtn = document.getElementById('next-amount');
    const prevAmountBtn = document.getElementById('prev-amount');
    
    // Step 3: Percentage Selection
    const percentageOptions = document.querySelectorAll('.percentage-option');
    const profitPercentageInput = document.getElementById('profit-percentage');
    const nextPercentageBtn = document.getElementById('next-percentage');
    const prevPercentageBtn = document.getElementById('prev-percentage');

    // Validate all required elements exist
    if (!userNameInput || !nextNameBtn) {
        throw new Error('Missing required elements for step 1');
    }
    if (!amountOptions.length || !initialAmountInput || !nextAmountBtn || !prevAmountBtn) {
        throw new Error('Missing required elements for step 2');
    }
    if (!percentageOptions.length || !profitPercentageInput || !nextPercentageBtn || !prevPercentageBtn) {
        throw new Error('Missing required elements for step 3');
    }

    // Initialize step 1
    setupNameStep(userNameInput, nextNameBtn);
    
    // Initialize step 2
    setupAmountStep(amountOptions, initialAmountInput, nextAmountBtn, prevAmountBtn);
    
    // Initialize step 3
    setupPercentageStep(percentageOptions, profitPercentageInput, nextPercentageBtn, prevPercentageBtn);

    console.log('[Auth] All setup steps initialized');
}

function setupNameStep(userNameInput, nextNameBtn) {
    console.log('[Auth] Setting up name step');
    
    nextNameBtn.addEventListener('click', function(e) {
        e.preventDefault();
        console.log('[Auth] Next button clicked on name step');
        
        try {
            const name = userNameInput.value.trim();
            console.log('[Auth] Name input:', name);
            
            if (!name) {
                showErrorToast('Please enter your name');
                userNameInput.focus();
                return;
            }
            
            if (name.length < 2 || name.length > 50) {
                showErrorToast('Name must be between 2-50 characters');
                return;
            }
            
            console.log('[Auth] Name validation passed');
            goToStep(2);
        } catch (error) {
            console.error('[Auth] Name step error:', error);
            showErrorToast('Error processing name. Please try again.');
        }
    });
}

function setupAmountStep(amountOptions, initialAmountInput, nextAmountBtn, prevAmountBtn) {
    console.log('[Auth] Setting up amount step');
    
    // Handle amount option clicks
    amountOptions.forEach(option => {
        option.addEventListener('click', function() {
            console.log('[Auth] Amount option selected:', this.dataset.amount);
            
            amountOptions.forEach(opt => opt.classList.remove('selected'));
            this.classList.add('selected');
            initialAmountInput.value = this.dataset.amount;
        });
    });
    
    // Handle custom amount input
    initialAmountInput.addEventListener('input', function() {
        console.log('[Auth] Custom amount entered:', this.value);
        amountOptions.forEach(opt => opt.classList.remove('selected'));
    });
    
    // Next button
    nextAmountBtn.addEventListener('click', function(e) {
        e.preventDefault();
        console.log('[Auth] Proceeding to percentage step');
        
        try {
            const amount = parseFloat(initialAmountInput.value);
            console.log('[Auth] Amount entered:', amount);
            
            if (isNaN(amount) {
                showErrorToast('Please enter a valid amount');
                initialAmountInput.focus();
                return;
            }
            
            if (amount <= 0) {
                showErrorToast('Amount must be greater than 0');
                return;
            }
            
            if (amount > 1000000) {
                showErrorToast('Amount cannot exceed $1,000,000');
                return;
            }
            
            console.log('[Auth] Amount validation passed');
            goToStep(3);
        } catch (error) {
            console.error('[Auth] Amount step error:', error);
            showErrorToast('Error processing amount. Please try again.');
        }
    });
    
    // Previous button
    prevAmountBtn.addEventListener('click', function(e) {
        e.preventDefault();
        console.log('[Auth] Returning to name step');
        goToStep(1);
    });
}

function setupPercentageStep(percentageOptions, profitPercentageInput, nextPercentageBtn, prevPercentageBtn) {
    console.log('[Auth] Setting up percentage step');
    
    // Handle percentage option clicks
    percentageOptions.forEach(option => {
        option.addEventListener('click', function() {
            console.log('[Auth] Percentage option selected:', this.dataset.percentage);
            
            percentageOptions.forEach(opt => opt.classList.remove('selected'));
            this.classList.add('selected');
            profitPercentageInput.value = this.dataset.percentage;
        });
    });
    
    // Handle custom percentage input
    profitPercentageInput.addEventListener('input', function() {
        console.log('[Auth] Custom percentage entered:', this.value);
        percentageOptions.forEach(opt => opt.classList.remove('selected'));
    });
    
    // Next button (complete setup)
    nextPercentageBtn.addEventListener('click', function(e) {
        e.preventDefault();
        console.log('[Auth] Completing setup');
        
        try {
            const percentage = parseFloat(profitPercentageInput.value);
            console.log('[Auth] Percentage entered:', percentage);
            
            if (isNaN(percentage)) {
                showErrorToast('Please enter a valid percentage');
                profitPercentageInput.focus();
                return;
            }
            
            if (percentage <= 0 || percentage > 100) {
                showErrorToast('Percentage must be between 0.1 and 100');
                return;
            }
            
            console.log('[Auth] Percentage validation passed');
            saveUserData();
            window.location.href = 'home.html';
        } catch (error) {
            console.error('[Auth] Percentage step error:', error);
            showErrorToast('Error processing percentage. Please try again.');
        }
    });
    
    // Previous button
    prevPercentageBtn.addEventListener('click', function(e) {
        e.preventDefault();
        console.log('[Auth] Returning to amount step');
        goToStep(2);
    });
}

function goToStep(stepNumber) {
    console.log(`[Auth] Navigating to step ${stepNumber}`);
    
    try {
        const setupSteps = document.querySelectorAll('.setup-step');
        const progressSteps = document.querySelectorAll('.progress-step');
        
        if (!setupSteps.length || !progressSteps.length) {
            throw new Error('Step elements not found');
        }
        
        // Hide all steps
        setupSteps.forEach(step => {
            step.classList.remove('active');
            step.style.display = 'none';
        });
        
        // Show the selected step
        const stepId = getStepId(stepNumber);
        const nextStep = document.getElementById(`${stepId}-step`);
        
        if (!nextStep) {
            throw new Error(`Step ${stepNumber} (${stepId}) not found`);
        }
        
        nextStep.classList.add('active');
        nextStep.style.display = 'block';
        
        // Update progress steps
        progressSteps.forEach((step, index) => {
            if (index < stepNumber) {
                step.classList.add('active');
            } else {
                step.classList.remove('active');
            }
        });
        
        console.log(`[Auth] Successfully transitioned to step ${stepNumber}`);
    } catch (error) {
        console.error('[Auth] Step transition failed:', error);
        showErrorToast('Error changing steps. Please refresh the page.');
    }
}

function getStepId(stepNumber) {
    const steps = ['name', 'amount', 'percentage'];
    return steps[stepNumber - 1] || '';
}

function saveUserData() {
    console.log('[Auth] Saving user data');
    
    try {
        const userNameInput = document.getElementById('user-name');
        const initialAmountInput = document.getElementById('initial-amount');
        const profitPercentageInput = document.getElementById('profit-percentage');
        
        if (!userNameInput || !initialAmountInput || !profitPercentageInput) {
            throw new Error('Missing required input fields');
        }
        
        const userData = {
            name: userNameInput.value.trim(),
            initialAmount: parseFloat(initialAmountInput.value),
            dailyPercentage: parseFloat(profitPercentageInput.value),
            profileImage: '',
            tradingPlan: generateInitialTradingPlan(parseFloat(initialAmountInput.value)),
            darkMode: false
        };
        
        console.log('[Auth] User data to save:', userData);
        localStorage.setItem('userData', JSON.stringify(userData));
        console.log('[Auth] User data saved successfully');
    } catch (error) {
        console.error('[Auth] Failed to save user data:', error);
        throw error; // Re-throw to be caught by calling function
    }
}

function generateInitialTradingPlan(initialAmount) {
    console.log(`[Auth] Generating trading plan for amount: ${initialAmount}`);
    
    const plan = [];
    let currentBalance = initialAmount;
    
    for (let day = 1; day <= 30; day++) {
        const profitToBeMade = currentBalance * 0.1; // Default to 10% for initial setup
        const expectedBalance = currentBalance + profitToBeMade;
        const savingBalance = profitToBeMade * 0.5;
        
        plan.push({
            day,
            balance: currentBalance,
            profitToBeMade,
            expectedBalance,
            lostMoney: 0,
            savingBalance,
            achieved: true
        });
        
        currentBalance = currentBalance + (profitToBeMade - (profitToBeMade * 0.5));
    }
    
    console.log('[Auth] Generated trading plan:', plan);
    return plan;
}

function showErrorToast(message) {
    console.error('[Auth] Showing error:', message);
    const toast = document.getElementById('toast');
    
    if (toast) {
        toast.textContent = message;
        toast.style.backgroundColor = '#e74c3c';
        toast.className = 'toast show';
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    } else {
        alert(message); // Fallback if toast doesn't exist
    }
}