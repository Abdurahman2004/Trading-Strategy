// DOM Elements
const darkModeToggle = document.getElementById('darkModeToggle');
const darkModeToggleMobile = document.getElementById('darkModeToggleMobile');
const darkModeStyle = document.getElementById('dark-mode-style');

// Initialize dark mode
document.addEventListener('DOMContentLoaded', function() {
    // Check for saved dark mode preference
    const darkModeEnabled = localStorage.getItem('darkMode') === 'enabled';
    
    // Apply dark mode if enabled
    if (darkModeEnabled && darkModeStyle) {
        darkModeStyle.disabled = false;
        
        // Update toggle icon
        if (darkModeToggle) {
            darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        }
        
        if (darkModeToggleMobile) {
            darkModeToggleMobile.innerHTML = '<i class="fas fa-sun"></i> Dark Mode';
        }
    }
    
    // Setup event listeners
    setupDarkModeListeners();
});

// Setup dark mode event listeners
function setupDarkModeListeners() {
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', toggleDarkMode);
    }
    
    if (darkModeToggleMobile) {
        darkModeToggleMobile.addEventListener('click', toggleDarkMode);
    }
}

// Toggle dark mode
function toggleDarkMode() {
    if (darkModeStyle) {
        const isDark = darkModeStyle.disabled;
        darkModeStyle.disabled = !isDark;
        
        // Save preference to localStorage
        localStorage.setItem('darkMode', isDark ? 'enabled' : 'disabled');
        
        // Update toggle icon
        if (darkModeToggle) {
            darkModeToggle.innerHTML = isDark ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
        }
        
        if (darkModeToggleMobile) {
            darkModeToggleMobile.innerHTML = isDark ? '<i class="fas fa-sun"></i> Dark Mode' : '<i class="fas fa-moon"></i> Light Mode';
        }
        
        showToast(`Dark mode ${isDark ? 'enabled' : 'disabled'}`, 'success');
    }
}