// DOM Elements
const tradingPlanBody = document.getElementById('tradingPlanBody');
const savePlanBtn = document.getElementById('savePlanBtn');
const resetPlanBtn = document.getElementById('resetPlanBtn');
const recalculateBtn = document.getElementById('recalculateBtn');
const initialAmountDisplay = document.getElementById('initialAmountDisplay');
const dailyPercentageDisplay = document.getElementById('dailyPercentageDisplay');
const totalBalance = document.getElementById('totalBalance');
const totalProfit = document.getElementById('totalProfit');
const totalExpected = document.getElementById('totalExpected');
const totalLost = document.getElementById('totalLost');
const totalSaving = document.getElementById('totalSaving');
const totalAchieved = document.getElementById('totalAchieved');

// Initialize trading plan
document.addEventListener('DOMContentLoaded', function() {
    loadTradingPlan();
    
    // Event listeners
    if (savePlanBtn) savePlanBtn.addEventListener('click', saveTradingPlan);
    if (resetPlanBtn) resetPlanBtn.addEventListener('click', resetTradingPlan);
    if (recalculateBtn) recalculateBtn.addEventListener('click', recalculatePlan);
});

// Load trading plan from localStorage
function loadTradingPlan() {
    const userData = JSON.parse(localStorage.getItem('userData'));
    
    if (userData) {
        // Display user info
        if (initialAmountDisplay) {
            initialAmountDisplay.textContent = `$${userData.initialAmount.toFixed(2)}`;
        }
        
        if (dailyPercentageDisplay) {
            dailyPercentageDisplay.textContent = `${userData.dailyPercentage}%`;
        }
        
        // Generate or load trading plan
        let tradingPlan = userData.tradingPlan;
        
        if (!tradingPlan || tradingPlan.length === 0) {
            tradingPlan = generateTradingPlan(userData.initialAmount, userData.dailyPercentage);
        }
        
        // Render the trading plan
        renderTradingPlan(tradingPlan);
        
        // Calculate and display totals
        calculateTotals(tradingPlan);
    }
}

// Generate a new trading plan
function generateTradingPlan(initialAmount, dailyPercentage) {
    const plan = [];
    let currentBalance = initialAmount;
    const percentage = dailyPercentage / 100;
    
    for (let day = 1; day <= 30; day++) {
        const profitToBeMade = currentBalance * percentage;
        const expectedBalance = currentBalance + profitToBeMade;
        const savingBalance = profitToBeMade * 0.5;
        
        plan.push({
            day,
            balance: currentBalance,
            profitToBeMade,
            expectedBalance,
            lostMoney: 0,
            savingBalance,
            achieved: true
        });
        
        currentBalance = currentBalance + (profitToBeMade - (profitToBeMade * 0.5));
    }
    
    return plan;
}

// Render the trading plan table
function renderTradingPlan(plan) {
    if (!tradingPlanBody) return;
    
    tradingPlanBody.innerHTML = '';
    
    plan.forEach(day => {
        const row = document.createElement('tr');
        
        // Highlight row if not achieved
        if (!day.achieved) {
            row.classList.add('not-achieved');
        }
        
        row.innerHTML = `
            <td>${day.day}</td>
            <td>$${day.balance.toFixed(2)}</td>
            <td>$${day.achieved ? day.profitToBeMade.toFixed(2) : '0.00'}</td>
            <td>$${day.achieved ? day.expectedBalance.toFixed(2) : day.balance.toFixed(2)}</td>
            <td><input type="number" min="0" step="0.01" value="${day.lostMoney.toFixed(2)}" data-day="${day.day}" class="lost-money-input"></td>
            <td>$${day.achieved ? day.savingBalance.toFixed(2) : (0 - day.lostMoney).toFixed(2)}</td>
            <td>
                <select data-day="${day.day}" class="achieved-select">
                    <option value="true" ${day.achieved ? 'selected' : ''}>Yes</option>
                    <option value="false" ${!day.achieved ? 'selected' : ''}>No</option>
                </select>
            </td>
        `;
        
        tradingPlanBody.appendChild(row);
    });
    
    // Add event listeners to selects and inputs
    document.querySelectorAll('.achieved-select').forEach(select => {
        select.addEventListener('change', function() {
            updateDayAchieved(parseInt(this.dataset.day), this.value === 'true');
        });
    });
    
    document.querySelectorAll('.lost-money-input').forEach(input => {
        input.addEventListener('change', function() {
            updateLostMoney(parseInt(this.dataset.day), parseFloat(this.value) || 0);
        });
    });
}

// Update day's achieved status
function updateDayAchieved(day, achieved) {
    const userData = JSON.parse(localStorage.getItem('userData'));
    
    if (userData && userData.tradingPlan) {
        const dayIndex = day - 1;
        userData.tradingPlan[dayIndex].achieved = achieved;
        
        // If not achieved, zero out profit and expected balance
        if (!achieved) {
            userData.tradingPlan[dayIndex].profitToBeMade = 0;
            userData.tradingPlan[dayIndex].expectedBalance = userData.tradingPlan[dayIndex].balance;
            userData.tradingPlan[dayIndex].savingBalance = 0 - userData.tradingPlan[dayIndex].lostMoney;
        } else {
            // Recalculate if achieved
            const percentage = userData.dailyPercentage / 100;
            userData.tradingPlan[dayIndex].profitToBeMade = userData.tradingPlan[dayIndex].balance * percentage;
            userData.tradingPlan[dayIndex].expectedBalance = userData.tradingPlan[dayIndex].balance + userData.tradingPlan[dayIndex].profitToBeMade;
            userData.tradingPlan[dayIndex].savingBalance = (userData.tradingPlan[dayIndex].profitToBeMade * 0.5) - userData.tradingPlan[dayIndex].lostMoney;
        }
        
        // Update subsequent days
        for (let i = dayIndex + 1; i < userData.tradingPlan.length; i++) {
            const prevDay = userData.tradingPlan[i - 1];
            
            if (prevDay.achieved) {
                userData.tradingPlan[i].balance = prevDay.balance + (prevDay.profitToBeMade - (prevDay.profitToBeMade * 0.5));
            } else {
                userData.tradingPlan[i].balance = prevDay.balance;
            }
            
            const percentage = userData.dailyPercentage / 100;
            userData.tradingPlan[i].profitToBeMade = userData.tradingPlan[i].balance * percentage;
            userData.tradingPlan[i].expectedBalance = userData.tradingPlan[i].balance + userData.tradingPlan[i].profitToBeMade;
            userData.tradingPlan[i].savingBalance = (userData.tradingPlan[i].profitToBeMade * 0.5) - userData.tradingPlan[i].lostMoney;
        }
        
        localStorage.setItem('userData', JSON.stringify(userData));
        renderTradingPlan(userData.tradingPlan);
        calculateTotals(userData.tradingPlan);
    }
}

// Update lost money for a day
function updateLostMoney(day, amount) {
    const userData = JSON.parse(localStorage.getItem('userData'));
    
    if (userData && userData.tradingPlan) {
        const dayIndex = day - 1;
        userData.tradingPlan[dayIndex].lostMoney = amount;
        
        // Update saving balance
        if (userData.tradingPlan[dayIndex].achieved) {
            userData.tradingPlan[dayIndex].savingBalance = (userData.tradingPlan[dayIndex].profitToBeMade * 0.5) - amount;
        } else {
            userData.tradingPlan[dayIndex].savingBalance = 0 - amount;
        }
        
        localStorage.setItem('userData', JSON.stringify(userData));
        renderTradingPlan(userData.tradingPlan);
        calculateTotals(userData.tradingPlan);
    }
}

// Calculate and display totals
function calculateTotals(plan) {
    if (!plan || plan.length === 0) return;
    
    let totalB = 0;
    let totalP = 0;
    let totalE = 0;
    let totalL = 0;
    let totalS = 0;
    let achievedCount = 0;
    
    plan.forEach(day => {
        totalB += day.balance;
        totalP += day.achieved ? day.profitToBeMade : 0;
        totalE += day.achieved ? day.expectedBalance : day.balance;
        totalL += day.lostMoney;
        totalS += day.savingBalance;
        if (day.achieved) achievedCount++;
    });
    
    // Update totals display
    if (totalBalance) totalBalance.textContent = `$${totalB.toFixed(2)}`;
    if (totalProfit) totalProfit.textContent = `$${totalP.toFixed(2)}`;
    if (totalExpected) totalExpected.textContent = `$${totalE.toFixed(2)}`;
    if (totalLost) totalLost.textContent = `$${totalL.toFixed(2)}`;
    if (totalSaving) totalSaving.textContent = `$${totalS.toFixed(2)}`;
    if (totalAchieved) totalAchieved.textContent = `${achievedCount}/${plan.length}`;
}

// Save trading plan
function saveTradingPlan() {
    const userData = JSON.parse(localStorage.getItem('userData'));
    
    if (userData) {
        // Update lost money values from inputs
        document.querySelectorAll('.lost-money-input').forEach(input => {
            const day = parseInt(input.dataset.day);
            const amount = parseFloat(input.value) || 0;
            
            if (userData.tradingPlan[day - 1]) {
                userData.tradingPlan[day - 1].lostMoney = amount;
                
                // Update saving balance
                if (userData.tradingPlan[day - 1].achieved) {
                    userData.tradingPlan[day - 1].savingBalance = (userData.tradingPlan[day - 1].profitToBeMade * 0.5) - amount;
                } else {
                    userData.tradingPlan[day - 1].savingBalance = 0 - amount;
                }
            }
        });
        
        localStorage.setItem('userData', JSON.stringify(userData));
        showToast('Trading plan saved successfully!', 'success');
    }
}

// Reset trading plan
function resetTradingPlan() {
    if (confirm('Are you sure you want to reset your trading plan? This cannot be undone.')) {
        const userData = JSON.parse(localStorage.getItem('userData'));
        
        if (userData) {
            userData.tradingPlan = generateTradingPlan(userData.initialAmount, userData.dailyPercentage);
            localStorage.setItem('userData', JSON.stringify(userData));
            renderTradingPlan(userData.tradingPlan);
            calculateTotals(userData.tradingPlan);
            showToast('Trading plan reset successfully!', 'success');
        }
    }
}

// Recalculate trading plan
function recalculatePlan() {
    const userData = JSON.parse(localStorage.getItem('userData'));
    
    if (userData) {
        // Update plan with current percentage
        const percentage = userData.dailyPercentage / 100;
        let currentBalance = userData.initialAmount;
        
        for (let i = 0; i < userData.tradingPlan.length; i++) {
            if (i > 0) {
                const prevDay = userData.tradingPlan[i - 1];
                if (prevDay.achieved) {
                    currentBalance = prevDay.balance + (prevDay.profitToBeMade - (prevDay.profitToBeMade * 0.5));
                } else {
                    currentBalance = prevDay.balance;
                }
            }
            
            userData.tradingPlan[i].balance = currentBalance;
            userData.tradingPlan[i].profitToBeMade = userData.tradingPlan[i].achieved ? currentBalance * percentage : 0;
            userData.tradingPlan[i].expectedBalance = userData.tradingPlan[i].achieved ? currentBalance + (currentBalance * percentage) : currentBalance;
            userData.tradingPlan[i].savingBalance = userData.tradingPlan[i].achieved ? 
                (userData.tradingPlan[i].profitToBeMade * 0.5) - userData.tradingPlan[i].lostMoney : 
                (0 - userData.tradingPlan[i].lostMoney);
        }
        
        localStorage.setItem('userData', JSON.stringify(userData));
        renderTradingPlan(userData.tradingPlan);
        calculateTotals(userData.tradingPlan);
        showToast('Trading plan recalculated!', 'success');
    }
}